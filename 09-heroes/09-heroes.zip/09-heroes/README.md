# Objetivos de la repositorio

Este proyecto se encarga de manejar los planes de la liga de la justicia


## Notas
Pueden hacer lo que quieran...

Estos son solo algunos cambios desde github. :)

### Hola mundo en readme (^_^)



CAMBIOS LOCALMENTE, y otros cambios localmente en la misma linea que en github con otros cambios desde github