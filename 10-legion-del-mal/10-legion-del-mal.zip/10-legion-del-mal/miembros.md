# Miembros

1. Lex Luthor
2. The Joker
3. Raven
4. Black Manta
5. Sinestro
6. Poison Ivy
7. Chronos
8. Catwoman
9. Deathstroke
10. Copperhead
11. Ra's al Ghul
12. Doctor Light
13. Gorilla Grodd
14. Captain Boomerang
15. Solomon Grundy
16. Felix Faust
17. Mr. Element
18. The Penguin
19. Talia al Ghul
20. Lady Shiva
21. Giganta
22. Deadshot
23. Scarecrow
