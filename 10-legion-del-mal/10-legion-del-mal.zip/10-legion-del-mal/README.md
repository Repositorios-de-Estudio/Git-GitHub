# Legion del Mal
Un repositorio para conquistar el mundo

Básicamente aprenderemos más sobre Git y GitHub con este proyecto


# Fernando


## Curso de Fernando en Udemy


Editador por mi 2023