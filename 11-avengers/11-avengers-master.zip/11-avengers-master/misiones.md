# MISIONES

* Investigar la casa de los dibujos
* Investigar a batman
* Capturar a Red Skull
