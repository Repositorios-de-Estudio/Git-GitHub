## Miembros

* Black panther
* Black Widow
* Capitán America
* Capitán Marvel
* Falcon
* Hank Pym
* Hawkeye
* Hulk
* Iron Man
* Luke Cage
* QuickSilver
* Scarlet Witch
* Spider Woman
* Thor
* Vision
* Wasp
* Antman
* Nick Fury
